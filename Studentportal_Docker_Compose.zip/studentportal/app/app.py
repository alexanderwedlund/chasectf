#!/usr/bin/env python3
"""Studentportalen: an intentionally vulnerable, self-contained classroom lab.

Only Python's standard library is used. See docs/lararhandledning.pdf before use.
Intentional weaknesses are marked LAB below. Do not reuse as a real portal.
"""
import base64
import hashlib
import hmac
import html
import json
import os
from pathlib import Path
import secrets
import signal
import sqlite3
import threading
import time
from contextlib import closing
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

DEFAULT_BOB_PASSWORD = "7Vq2!L9mR4@tK8pX6zS3#nB5"
SESSION_SECONDS = 3 * 60 * 60
STATIC = Path(__file__).parent / "static"
FLAGS = {
    "error": "flag{security_misconfiguration}",
    "network": "flag{excessive_data_exposure}",
    "source": "flag{cryptographic_failures}",
    "idor": "flag{broken_access_control}",
    "sqli": "flag{injection}",
}
BOB = {"name": "Bob Lind", "email": "bob.lind@student.example", "phone": "070-123 45 67",
       "bio": "Läser IT-säkerhet. Gillar nätverk och problemlösning."}
ALICE = {"name": "Alice Berg", "email": "alice.berg@student.example", "phone": "070-987 65 43",
         "bio": "Läser IT-säkerhet. Arbetar med gruppens nätverksprojekt."}


def escape(value):
    return html.escape(str(value), quote=True)


class PortalState:
    def __init__(self, bob_password=None):
        password = bob_password or os.environ.get("BOB_PASSWORD", DEFAULT_BOB_PASSWORD)
        if len(password) < 16:
            raise ValueError("BOB_PASSWORD måste innehålla minst 16 tecken.")
        self.salt = secrets.token_bytes(32)
        # These passwords are new on every start and never sent to a browser or log.
        self.alice_password = secrets.token_urlsafe(48)
        self.admin_password = secrets.token_urlsafe(48)
        self.student_hashes = {"bob_student": self.digest(password),
                               "alice_student": self.digest(self.alice_password)}
        self.sessions = {}
        self.lock = threading.RLock()

    def digest(self, password):
        return hashlib.pbkdf2_hmac("sha256", password.encode(), self.salt, 200_000)

    def authenticate(self, username, password):
        if username == "administrator":
            # LAB: real SQL injection in an isolated, administrator-only database.
            # Alice and Bob do not exist in this table. No shared database is modified.
            with closing(sqlite3.connect(":memory:")) as db:
                db.execute("CREATE TABLE admin_accounts (username TEXT, password TEXT)")
                db.execute("INSERT INTO admin_accounts VALUES (?, ?)",
                           ("administrator", self.admin_password))
                db.execute("PRAGMA query_only = ON")
                db.set_progress_handler(lambda: 1, 50_000)
                query = ("SELECT username FROM admin_accounts "
                         f"WHERE username = 'administrator' AND password = '{password}'")
                try:
                    row = db.execute(query).fetchone()
                except sqlite3.Error:
                    return None
                return "administrator" if row and row[0] == "administrator" else None
        # No string-built SQL on the student authentication path.
        stored = self.student_hashes.get(username)
        supplied = self.digest(password)
        return username if stored and hmac.compare_digest(stored, supplied) else None

    def new_session(self, username=None):
        now = time.time()
        sid = secrets.token_urlsafe(32)
        record = {"username": username, "csrf": secrets.token_urlsafe(32),
                  "expires": now + SESSION_SECONDS, "profile": dict(BOB if username != "alice_student" else ALICE)}
        with self.lock:
            for old in [key for key, value in self.sessions.items() if value["expires"] < now]:
                del self.sessions[old]
            self.sessions[sid] = record
        return sid, record

    def get_session(self, sid):
        with self.lock:
            record = self.sessions.get(sid)
            if record and record["expires"] > time.time():
                return record
            self.sessions.pop(sid, None)
        return None

    def remove_session(self, sid):
        with self.lock:
            self.sessions.pop(sid, None)


def page(title, content, session=None, active="", script=False, source_comment=False):
    username = session.get("username") if session else None
    navigation = ""
    if username:
        if username == "administrator":
            links = '<a class="active" href="/administration">Administration</a>'
        else:
            links = (f'<a class="{"active" if active == "home" else ""}" href="/">Översikt</a>'
                     f'<a class="{"active" if active == "profile" else ""}" href="/profil?student={escape(username)}">Min profil</a>')
        navigation = f'''<nav aria-label="Huvudmeny">{links}</nav>
            <div class="account"><span>{escape(username)}</span>
            <form method="post" action="/logout"><input type="hidden" name="csrf" value="{escape(session['csrf'])}">
            <button class="text-button" type="submit">Logga ut</button></form></div>'''
    # LAB: a developer mistakes reversible encoding for encryption.
    comment = ("\n<!-- TODO: Ta bort i produktion! Intern verifieringskod, skyddad med Base64: "
               + base64.b64encode(FLAGS["source"].encode()).decode() + " -->\n") if source_comment else ""
    return f'''<!doctype html>
<html lang="sv"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{escape(title)} · Studentportalen</title><link rel="stylesheet" href="/static/style.css">
{"<script src='/static/portal.js' defer></script>" if script else ""}</head>
<body><header class="site-header"><div class="header-inner"><a class="brand" href="/">Studentportalen</a>
{navigation}</div></header>{comment}<main id="main" class="{"login-main" if not username else ""}">{content}</main>
<footer class="site-footer">Studentservice <span>Vardagar 08.00–16.00</span></footer></body></html>'''


def login_page(session, error=""):
    message = f'<p class="notice error" role="alert">{escape(error)}</p>' if error else ""
    return page("Logga in", f'''<section class="login-box"><p class="eyebrow">DITT STUDIEKONTO</p>
<h1>Logga in</h1><p class="muted">Använd ditt användarnamn och lösenord.</p>{message}
<form method="post" action="/login"><input type="hidden" name="csrf" value="{escape(session['csrf'])}">
<label for="username">Användarnamn</label><input id="username" name="username" autocomplete="username" maxlength="80" required autofocus>
<label for="password">Lösenord</label><input id="password" name="password" type="password" autocomplete="current-password" maxlength="256" required>
<button class="primary full" type="submit">Logga in</button></form>
<p class="login-help">Problem med ditt konto? Kontakta studentservice.</p></section>''', session)


def home_page(session):
    first_name = session["profile"]["name"].split()[0]
    return page("Översikt", f'''<div class="page-heading"><div><p class="eyebrow">MINA STUDIER</p>
<h1>Hej {escape(first_name)}</h1><p class="muted">Här hittar du din studieöversikt och dina uppgifter.</p></div>
<span class="term">Höstterminen 2026</span></div>
<div class="home-grid"><section class="panel study-panel"><div class="section-heading"><h2>Aktuell kurs</h2>
<button class="text-button" type="button" id="refresh-studies">Uppdatera</button></div>
<p class="course-title" id="course-name">IT-säkerhet</p><p class="muted" id="course-detail">Hämtar kursinformation…</p>
<dl class="study-details"><div><dt>Nästa undervisningstillfälle</dt><dd id="next-session">Hämtar…</dd></div>
<div><dt>Plats</dt><dd id="room">Hämtar…</dd></div></dl><p id="study-status" class="small muted" role="status"></p></section>
<section class="panel"><h2>Ärenden</h2><a class="service-link" href="/profil?student={escape(session['username'])}">
<span>Uppdatera kontaktuppgifter<small>Telefon, e-post och presentation</small></span><span aria-hidden="true">›</span></a>
<a class="service-link" href="/intyg/studieintyg"><span>Hämta studieintyg<small>Intyg om dina pågående studier</small></span>
<span aria-hidden="true">›</span></a></section></div>
<section class="announcements"><h2>Meddelanden</h2><article><p class="small muted">Studentservice</p>
<h3>Kontrollera dina kontaktuppgifter</h3><p>Se gärna över telefonnummer och e-post under Min profil inför nästa kurs.</p></article>
<article><p class="small muted">Biblioteket</p><h3>Grupprum på plan 2</h3><p>Grupprummen är öppna för självstudier på vardagar till klockan 18.</p></article></section>''',
                session, active="home", script=True)


def profile_page(session, target, profile, saved=False):
    own = target == session["username"]
    notice = '<p class="notice success" role="status">Dina uppgifter har sparats.</p>' if saved else ""
    if own:
        details = f'''<form method="post" action="/profil"><input type="hidden" name="csrf" value="{escape(session['csrf'])}">
<input type="hidden" name="student" value="{escape(target)}"><div class="form-grid"><div><label for="name">Namn</label>
<input id="name" name="name" value="{escape(profile['name'])}" maxlength="80" required></div><div><label for="email">E-post</label>
<input id="email" name="email" type="email" value="{escape(profile['email'])}" maxlength="120" required></div></div>
<label for="phone">Telefon</label><input class="short-input" id="phone" name="phone" type="tel" value="{escape(profile['phone'])}" maxlength="40">
<label for="bio">Kort presentation</label><textarea id="bio" name="bio" rows="4" maxlength="600">{escape(profile['bio'])}</textarea>
<div class="form-actions"><button class="primary" type="submit">Spara ändringar</button><a class="secondary-link" href="/">Till översikten</a></div></form>'''
    else:
        details = f'''<dl class="profile-details"><div><dt>E-post</dt><dd>{escape(profile['email'])}</dd></div>
<div><dt>Telefon</dt><dd>{escape(profile['phone'])}</dd></div><div><dt>Kort presentation</dt><dd>{escape(profile['bio'])}</dd></div></dl>'''
    # LAB: Alice's private note belongs to Alice, but the GET handler lacks owner authorization.
    private_note = (f'<section class="private-note"><h2>Anteckning från studievägledaren</h2>'
                    f'<p>Underlag för individuell studieplan: <code>{FLAGS["idor"]}</code></p></section>') if target == "alice_student" else ""
    return page("Profil", f'''<div class="page-heading"><div><p class="eyebrow">STUDENTUPPGIFTER</p>
<h1>{escape(profile['name'])}</h1><p class="muted">{escape(target)} · IT-säkerhet</p></div><span class="term">Aktiv student</span></div>
{notice}<section class="panel profile-panel"><h2>Kontaktuppgifter</h2>{details}</section>{private_note}''',
                session, active="profile", source_comment=True)


def certificate_error(session):
    details = f'''DocumentNotFound: study-certificate.pdf

Server: nginx/1.26.2
Upstream: studentportal-app:8080
Application root: /srv/studentportal/current
Document path: /srv/studentportal/shared/certificates/study-certificate.pdf
Database host: db-student.internal:5432
Environment: production
Diagnostic reference: {FLAGS['error']}'''
    return page("Studieintyget saknas", f'''<section class="error-page"><p class="eyebrow">404</p>
<h1>Studieintyget kunde inte hämtas</h1><p>Försök igen senare eller kontakta studentservice.</p>
<pre class="trace">{escape(details)}</pre><a class="primary" href="/">Till översikten</a></section>''', session)


class PortalServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, state=None):
        self.state = state or PortalState()
        super().__init__(address, PortalHandler)


class PortalHandler(BaseHTTPRequestHandler):
    server_version = "Studentportal"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, fmt, *args):
        # Avoid logging usernames, submitted passwords, query strings or flag values.
        return

    def send(self, status, body, content_type="text/html; charset=utf-8", headers=None):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def redirect(self, location, cookie=None):
        headers = {"Location": location}
        if cookie:
            headers["Set-Cookie"] = cookie
        self.send(303, "", headers=headers)

    @staticmethod
    def cookie(sid, clear=False):
        secure = "; Secure" if os.environ.get("COOKIE_SECURE") == "1" else ""
        return f"portal_session={sid}; Path=/; HttpOnly; SameSite=Lax; Max-Age={0 if clear else SESSION_SECONDS}{secure}"

    def session(self):
        jar = SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
            sid = jar["portal_session"].value if "portal_session" in jar else ""
        except (KeyError, ValueError, CookieError):
            sid = ""
        return sid, self.server.state.get_session(sid)

    def require_login(self):
        sid, session = self.session()
        if not session or not session["username"]:
            self.redirect("/login")
            return None
        return sid, session

    def error_page(self, status, message, session=None):
        self.send(status, page(str(status), f'<section class="error-page"><p class="eyebrow">{status}</p>'
                  f'<h1>{escape(message)}</h1><p><a href="/">Till översikten</a></p></section>', session))

    def do_GET(self):
        parsed = urlsplit(self.path)
        path = parsed.path
        if path == "/healthz":
            self.send(200, '{"status":"ok"}', "application/json")
            return
        if path in ("/static/style.css", "/static/portal.js"):
            filename = path.rsplit("/", 1)[1]
            self.send(200, (STATIC / filename).read_bytes(),
                      "text/css; charset=utf-8" if filename.endswith("css") else "text/javascript; charset=utf-8")
            return
        if path == "/favicon.ico":
            self.send(204, b"", "image/x-icon")
            return
        if path == "/login":
            _, session = self.session()
            if session and session["username"]:
                self.redirect("/administration" if session["username"] == "administrator" else "/")
            elif session:
                # Tabs share a cookie. Keep the anonymous session and form token
                # so opening another login page does not invalidate an older one.
                self.send(200, login_page(session))
            else:
                sid, session = self.server.state.new_session()
                self.send(200, login_page(session), headers={"Set-Cookie": self.cookie(sid)})
            return
        allowed = {"/", "/profil", "/api/studier", "/intyg/studieintyg", "/administration"}
        if path not in allowed:
            self.error_page(404, "Sidan finns inte")
            return
        authenticated = self.require_login()
        if not authenticated:
            return
        _, session = authenticated
        if path == "/":
            if session["username"] == "administrator":
                self.redirect("/administration")
            else:
                self.send(200, home_page(session))
        elif path == "/profil":
            params = parse_qs(parsed.query, keep_blank_values=True)
            targets = params.get("student", [session["username"]])
            if len(targets) != 1:
                self.error_page(400, "Ogiltig förfrågan", session)
                return
            target = targets[0]
            # This boundary is deliberate: administrator is never exposed by IDOR.
            if target == "administrator":
                self.error_page(403, "Du saknar behörighet", session)
            elif target not in ("bob_student", "alice_student"):
                self.error_page(404, "Studenten finns inte", session)
            else:
                # LAB: target is checked as a student, but not against the requester.
                profile = session["profile"] if target == session["username"] else dict(ALICE if target == "alice_student" else BOB)
                self.send(200, profile_page(session, target, profile, params.get("sparad") == ["1"]))
        elif path == "/api/studier":
            # LAB: the client only renders selected fields, yet receives the entire response.
            payload = {"course": "Grundläggande informationssäkerhet", "credits": "25 YH-poäng",
                       "next_session": "I dag, 10.00–12.00", "room": "Sal B204",
                       "internal_reference": FLAGS["network"]}
            self.send(200, json.dumps(payload, ensure_ascii=False), "application/json; charset=utf-8")
        elif path == "/intyg/studieintyg":
            # LAB: actual HTTP 404, with deliberately fictional diagnostic details.
            self.send(404, certificate_error(session))
        elif path == "/administration":
            if session["username"] != "administrator":
                self.error_page(403, "Du saknar behörighet", session)
            else:
                self.send(200, page("Administration", f'''<div class="page-heading"><div><p class="eyebrow">ADMINISTRATION</p>
<h1>Portalöversikt</h1><p class="muted">Du är inloggad som administrator.</p></div></div>
<section class="panel"><h2>Systeminformation</h2><dl class="profile-details"><div><dt>Aktiva konton</dt><dd>3</dd></div>
<div><dt>Termin</dt><dd>Höstterminen 2026</dd></div><div><dt>Intern verifieringskod</dt><dd><code>{FLAGS['sqli']}</code></dd></div></dl></section>''', session))

    def read_form(self):
        if self.headers.get("Transfer-Encoding"):
            self.send(400, "Ogiltig förfrågan", "text/plain; charset=utf-8")
            return None
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size < 0 or size > 16_384:
                self.send(413, "För stor förfrågan", "text/plain; charset=utf-8")
                return None
            values = parse_qs(self.rfile.read(size).decode("utf-8"), keep_blank_values=True, max_num_fields=12)
        except (ValueError, UnicodeError):
            self.send(400, "Ogiltig förfrågan", "text/plain; charset=utf-8")
            return None
        if any(len(items) != 1 for items in values.values()):
            self.send(400, "Ogiltig förfrågan", "text/plain; charset=utf-8")
            return None
        return {key: items[0] for key, items in values.items()}

    def do_POST(self):
        path = urlsplit(self.path).path
        if path not in ("/login", "/logout", "/profil"):
            self.error_page(404, "Sidan finns inte")
            return
        form = self.read_form()
        if form is None:
            return
        sid, session = self.session()
        if not session or not hmac.compare_digest(session["csrf"].encode(), form.get("csrf", "").encode()):
            if path == "/login" and (not session or not session["username"]):
                # Reject the stale submission, but show a fresh usable form.
                headers = {}
                if not session:
                    sid, session = self.server.state.new_session()
                    headers["Set-Cookie"] = self.cookie(sid)
                self.send(403, login_page(session,
                    "Inloggningssidan har uppdaterats. Fyll i dina uppgifter och försök igen."),
                    headers=headers)
            else:
                message = ("Sessionen saknas eller har gått ut. Logga in igen." if not session else
                           "Formuläret är inte längre giltigt. Ladda om sidan och försök igen.")
                self.error_page(403, message)
            return
        if path == "/login":
            username, password = form.get("username", "").strip(), form.get("password", "")
            if len(username) > 80 or len(password) > 256 or not password:
                self.send(401, login_page(session, "Fel användarnamn eller lösenord."))
                return
            user = self.server.state.authenticate(username, password)
            if not user:
                self.send(401, login_page(session, "Fel användarnamn eller lösenord."))
                return
            self.server.state.remove_session(sid)
            new_sid, _ = self.server.state.new_session(user)
            self.redirect("/administration" if user == "administrator" else "/", self.cookie(new_sid))
        elif not session["username"]:
            self.redirect("/login")
        elif path == "/logout":
            self.server.state.remove_session(sid)
            self.redirect("/login", self.cookie("", clear=True))
        elif path == "/profil":
            target = form.get("student", session["username"])
            if target != session["username"] or target not in ("bob_student", "alice_student"):
                self.error_page(403, "Du saknar behörighet", session)
                return
            profile = {key: form.get(key, "").strip() for key in BOB}
            if (not profile["name"] or not profile["email"] or "@" not in profile["email"] or
                any(len(profile[key]) > limit for key, limit in (("name", 80), ("email", 120), ("phone", 40), ("bio", 600)))):
                self.error_page(400, "Kontrollera dina kontaktuppgifter", session)
                return
            with self.server.state.lock:
                session["profile"] = profile
            self.redirect(f"/profil?student={target}&sparad=1")


def main():
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8080"))
    server = PortalServer((host, port))

    def stop(_signum, _frame):
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    print(f"Studentportalen lyssnar på port {port}", flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
