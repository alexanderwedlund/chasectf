"use strict";

async function loadStudies() {
  const status = document.getElementById("study-status");
  const button = document.getElementById("refresh-studies");
  button.disabled = true;
  status.textContent = "";
  try {
    const response = await fetch("/api/studier", {cache: "no-store"});
    if (!response.ok || !response.headers.get("content-type").includes("application/json")) {
      throw new Error("Kursinformationen är inte tillgänglig.");
    }
    const data = await response.json();
    document.getElementById("course-name").textContent = data.course;
    document.getElementById("course-detail").textContent = data.credits;
    document.getElementById("next-session").textContent = data.next_session;
    document.getElementById("room").textContent = data.room;
  } catch (_) {
    status.textContent = "Kursinformationen kunde inte hämtas. Försök igen.";
  } finally {
    button.disabled = false;
  }
}

document.getElementById("refresh-studies").addEventListener("click", loadStudies);
loadStudies();
